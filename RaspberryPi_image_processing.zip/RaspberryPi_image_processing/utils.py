# Copyright 2021 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Utility functions to display the pose detection results."""
import random
import cv2
import serial
import time 
import string
import pynmea2  
import numpy as np
from tflite_support.task import processor
from gtts import gTTS
import os
from paho.mqtt import client as mqtt_client
buzzer =""
from gpiozero import MotionSensor, LED, Button
from time import sleep

pir1 = MotionSensor(27)
button = Button(22)
red = LED(4)

# Configure the serial port
ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)

def send_sms(phone_number, message):
    # Initialize the SIM800L module
    ser.write(b'AT\r\n')
    time.sleep(1)
    ser.flushInput()

    # Set the module to text mode
    ser.write(b'AT+CMGF=1\r\n')
    time.sleep(1)
    ser.flushInput()

    # Set the recipient phone number
    ser.write(f'AT+CMGS="{phone_number}"\r\n'.encode('utf-8'))
    time.sleep(1)
    ser.flushInput()

    # Send the SMS message
    ser.write(message.encode('utf-8'))
    time.sleep(1)

    # Send the Ctrl+Z (0x1A) to indicate the end of the message
    ser.write(bytes([26]))
    time.sleep(1)

    # Wait for the module to send the SMS
    response = ser.read(ser.inWaiting()).decode('utf-8')
    print(response)





_MARGIN = 10  # pixels
_ROW_SIZE = 10  # pixels
_FONT_SIZE = 1
_FONT_THICKNESS = 1
_TEXT_COLOR = (0, 0, 255)  # red


broker = 'vaibhav'
port = 1883
topic = "photos"
# Generate a Client ID with the subscribe prefix.
client_id = f'subscribe-{random.randint(0, 100)}'
# username = 'emqx'
# password = 'public'

#red.off()
def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    # client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")
        global buzzer
        buzzer=msg.payload.decode()
        print()
        print(buzzer)
    client.subscribe(topic)
    client.on_message = on_message


def run():
    client = connect_mqtt()
    subscribe(client)
    client.loop_forever()

def main2():
    ser1=serial.Serial("/dev/ttyAMA1", baudrate=9600, timeout=1)
    dataout =pynmea2.NMEAStreamReader() 
    newdata=ser1.readline()
    gps = "Latitude=" + str(0.00) + "and Longitude=" +str(0.00)
    #print(newdata)
    if '$GPRMC' in str(newdata):
        print(newdata.decode('utf-8'))
        newmsg=pynmea2.parse(newdata.decode('utf-8'))  
        lat=newmsg.latitude 
        lng=newmsg.longitude 
        gps = "Latitude=" + str(lat) + "and Longitude=" +str(lng) 
        print(gps)
    pir1.wait_for_motion()
    print("sms send")
    send_sms('+919209362497', gps)
    time.sleep(10)

def speak(a):
    tts = gTTS(text=a, lang='en')
    tts.save("audio.mp3")
    os.system("mpg321 audio.mp3")


def CountFreq(li):
    freq = {}
    for items in li:
        freq[items] = li.count(items)
    #print(freq)
    a=str(freq)
    if not button.is_pressed:
         print("Button is pressed")
         speak(a)
         print(a)




def visualize(
    image: np.ndarray,
    detection_result: processor.DetectionResult,
) -> np.ndarray:
  """Draws bounding boxes on the input image and return it.

  Args:
    image: The input RGB image.
    detection_result: The list of all "Detection" entities to be visualize.

  Returns:
    Image with bounding boxes.
  """
  list=[]
  for detection in detection_result.detections:
    # Draw bounding_box
    bbox = detection.bounding_box
    start_point = bbox.origin_x, bbox.origin_y
    end_point = bbox.origin_x + bbox.width, bbox.origin_y + bbox.height
    cv2.rectangle(image, start_point, end_point, _TEXT_COLOR, 3)

    # Draw label and score
    category = detection.categories[0]
    category_name = category.category_name
    list.append(category_name)
    probability = round(category.score, 2)
    result_text = category_name + ' (' + str(probability) + ')'
    text_location = (_MARGIN + bbox.origin_x,
                     _MARGIN + _ROW_SIZE + bbox.origin_y)
    cv2.putText(image, result_text, text_location, cv2.FONT_HERSHEY_PLAIN,
                _FONT_SIZE, _TEXT_COLOR, _FONT_THICKNESS)
  
  CountFreq(list)
  global buzzer
  if(buzzer=="CLOSE"):
 
      red.on()
      sleep(1)
      buzzer="ok"
  else:
      red.off()
  return image
