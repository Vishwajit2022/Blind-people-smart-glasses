import serial
import time
import serial
import time 
import string
import pynmea2  
from gpiozero import MotionSensor, LED
pir = MotionSensor(27)
led = LED(4)

# Configure the serial port
ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)

def send_sms(phone_number, message):
    # Initialize the SIM800L module
    ser.write(b'AT\r\n')
    time.sleep(1)
    ser.flushInput()

    # Set the module to text mode
    ser.write(b'AT+CMGF=1\r\n')
    time.sleep(1)
    ser.flushInput()

    # Set the recipient phone number
    ser.write(f'AT+CMGS="{phone_number}"\r\n'.encode('utf-8'))
    time.sleep(1)
    ser.flushInput()

    # Send the SMS message
    ser.write(message.encode('utf-8'))
    time.sleep(1)

    # Send the Ctrl+Z (0x1A) to indicate the end of the message
    ser.write(bytes([26]))
    time.sleep(1)

    # Wait for the module to send the SMS
    response = ser.read(ser.inWaiting()).decode('utf-8')
    print(response)




while 1:
    ser1=serial.Serial("/dev/ttyAMA1", baudrate=9600, timeout=1)
    dataout =pynmea2.NMEAStreamReader() 
    newdata=ser1.readline()
    gps = "Latitude=" + str(0.00) + "and Longitude=" +str(0.00)
    #print(newdata)
    if '$GPRMC' in str(newdata):
        print(newdata.decode('utf-8'))
        newmsg=pynmea2.parse(newdata.decode('utf-8'))  
        lat=newmsg.latitude 
        lng=newmsg.longitude 
        gps = "Latitude=" + str(lat) + "and Longitude=" +str(lng) 
        print(gps)
    pir.wait_for_motion()
    print("sms send")
    send_sms('+919209362497', gps)
    time.sleep(10)

# Replace 'your_phone_number' with the recipient's phone number
# Replace 'your_message' with the message you want to send


# Close the serial port
ser.close()
