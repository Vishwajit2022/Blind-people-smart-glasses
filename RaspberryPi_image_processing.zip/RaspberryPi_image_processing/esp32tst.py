import urllib.request
import time
import numpy as np
import cv2
def cam():

    # Use urllib to get the image from the IP camera
    imgResp = cv2.VideoCapture("http://192.168.178.234:80")
    rdy,frame1 = imgResp.read()
    # Numpy to convert into a array
    key = cv2.waitKey(5)
  
    # Finally decode the array to OpenCV usable format ;) 
    return frame1
   

   